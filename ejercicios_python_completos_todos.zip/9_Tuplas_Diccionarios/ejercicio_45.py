class AgendaTuplas:
    def __init__(self):
        self.data = {}  # nombre -> (edad, ciudad)

    def agregar(self, nombre, edad, ciudad):
        self.data[nombre] = (edad, ciudad)

    def obtener(self, nombre):
        return self.data.get(nombre)

if __name__ == "__main__":
    a = AgendaTuplas()
    a.agregar('Ana',30,'Bogota')
    print(a.obtener('Ana'))
