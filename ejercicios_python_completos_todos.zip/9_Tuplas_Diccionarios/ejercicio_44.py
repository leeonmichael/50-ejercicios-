def actualizar_ciudad(dic, nombre, nueva_ciudad):
    if nombre in dic:
        edad = dic[nombre][0]
        dic[nombre] = (edad, nueva_ciudad)
        return True
    return False

if __name__ == "__main__":
    d = {'Ana':(30,'B')}
    print(actualizar_ciudad(d,'Ana','Cali'), d)
