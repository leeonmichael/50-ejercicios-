def ordenar_por_edad(dic):
    return dict(sorted(dic.items(), key=lambda kv: kv[1][0]))

if __name__ == "__main__":
    d = {'Ana':(30,'B'), 'Luis':(25,'C'), 'Zoe':(28,'A')}
    print(ordenar_por_edad(d))
