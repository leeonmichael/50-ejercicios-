def diccionario_de_tuplas(personas):
    # personas: list of (nombre, (edad, ciudad))
    return {nombre: datos for nombre, datos in personas}

if __name__ == "__main__":
    datos = [('Ana',(30,'Bogota')), ('Luis',(25,'Cali'))]
    print(diccionario_de_tuplas(datos))
