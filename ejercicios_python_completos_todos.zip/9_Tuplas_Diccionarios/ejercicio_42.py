def promedio_edades(dic):
    edades = [t[0] for t in dic.values()]
    return sum(edades)/len(edades) if edades else 0

if __name__ == "__main__":
    d = {'Ana':(30,'Bogota'), 'Luis':(25,'Cali')}
    print(promedio_edades(d))
