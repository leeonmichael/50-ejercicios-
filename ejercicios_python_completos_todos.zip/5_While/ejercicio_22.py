def cuenta_regresiva(n):
    while n >= 0:
        print(n)
        n -= 1

if __name__ == "__main__":
    cuenta_regresiva(5)
