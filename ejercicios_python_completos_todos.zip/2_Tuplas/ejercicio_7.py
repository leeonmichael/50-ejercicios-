def buscar_en_tupla(tupla, valor):
    for item in tupla:
        if item == valor:
            return True
    return False

if __name__ == "__main__":
    t = (1,3,5,7)
    print(buscar_en_tupla(t, 3))
    print(buscar_en_tupla(t, 2))
