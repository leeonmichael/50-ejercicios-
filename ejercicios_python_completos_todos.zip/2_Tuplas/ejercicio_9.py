def intercambio(a, b):
    return b, a

if __name__ == "__main__":
    a, b = 5, 10
    print("Antes:", a, b)
    a, b = intercambio(a, b)
    print("Después:", a, b)
