def lista_a_tupla(lista):
    return tuple(lista)

if __name__ == "__main__":
    print(lista_a_tupla([1,2,3]))
