import math
def distancia_al_origen(puntos):
    return [math.hypot(x, y) for x, y in puntos]

if __name__ == "__main__":
    coords = [(3,4),(1,1),(0,5)]
    print(distancia_al_origen(coords))
