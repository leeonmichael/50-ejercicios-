import math
class Coordenada:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def distancia(self, otra):
        return math.hypot(self.x - otra.x, self.y - otra.y)

if __name__ == "__main__":
    p1 = Coordenada(1,2)
    p2 = Coordenada(4,6)
    print("Distancia:", p1.distancia(p2))
