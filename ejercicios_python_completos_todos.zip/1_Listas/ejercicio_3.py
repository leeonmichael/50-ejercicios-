def suma_lista(lista):
    total = 0
    for num in lista:
        total += num
    return total

if __name__ == "__main__":
    print("Suma:", suma_lista([1,2,3,4,5]))
