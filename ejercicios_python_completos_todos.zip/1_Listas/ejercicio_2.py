def eliminar_duplicados(lista):
    resultado = []
    for item in lista:
        if item not in resultado:
            resultado.append(item)
    return resultado

if __name__ == "__main__":
    l = [1,2,2,3,4,4,5,1]
    print("Original:", l)
    print("Sin duplicados:", eliminar_duplicados(l))
