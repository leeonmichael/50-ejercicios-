class ListaEstadisticas:
    def __init__(self, lista):
        if not lista:
            raise ValueError("La lista no puede estar vacía")
        self.lista = lista

    def promedio(self):
        return sum(self.lista)/len(self.lista)

    def maximo(self):
        return max(self.lista)

    def minimo(self):
        return min(self.lista)

if __name__ == "__main__":
    l = ListaEstadisticas([3,5,7,2,9])
    print("Promedio:", l.promedio())
    print("Máximo:", l.maximo())
    print("Mínimo:", l.minimo())
