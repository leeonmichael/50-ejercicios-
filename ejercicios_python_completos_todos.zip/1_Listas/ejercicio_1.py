def contar_pares_impares(lista):
    pares = sum(1 for x in lista if isinstance(x, int) and x % 2 == 0)
    impares = sum(1 for x in lista if isinstance(x, int) and x % 2 != 0)
    return pares, impares

if __name__ == "__main__":
    nums = [1,2,3,4,5,6,7,8,9,10]
    pares, impares = contar_pares_impares(nums)
    print("Lista:", nums)
    print("Pares:", pares, "Impares:", impares)
