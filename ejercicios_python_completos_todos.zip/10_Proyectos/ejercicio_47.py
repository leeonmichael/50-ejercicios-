class SistemaNotas:
    def __init__(self):
        self.estudiantes = {}  # nombre -> [notas]

    def agregar_nota(self, nombre, nota):
        self.estudiantes.setdefault(nombre, []).append(nota)

    def promedio(self, nombre):
        notas = self.estudiantes.get(nombre, [])
        return sum(notas)/len(notas) if notas else 0

if __name__ == "__main__":
    s = SistemaNotas()
    s.agregar_nota('Ana',4.5)
    s.agregar_nota('Ana',3.5)
    print(s.promedio('Ana'))
