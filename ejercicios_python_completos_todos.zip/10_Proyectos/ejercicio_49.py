class Biblioteca:
    def __init__(self):
        self.libros = []  # {'titulo','autor','prestado':False}

    def agregar(self, titulo, autor):
        self.libros.append({'titulo':titulo,'autor':autor,'prestado':False})

    def prestar(self, titulo):
        for l in self.libros:
            if l['titulo']==titulo and not l['prestado']:
                l['prestado'] = True
                return True
        return False

    def devolver(self, titulo):
        for l in self.libros:
            if l['titulo']==titulo and l['prestado']:
                l['prestado'] = False
                return True
        return False

if __name__ == "__main__":
    b = Biblioteca()
    b.agregar('El Quijote','Cervantes')
    b.prestar('El Quijote')
    print(b.libros)
    b.devolver('El Quijote')
    print(b.libros)
