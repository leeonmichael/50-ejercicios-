import random
def juego_adivina(maximo=50):
    secreto = random.randint(1, maximo)
    intentos = 0
    pista = ''
    while True:
        intento = random.randint(1, maximo)  # ejemplo no interactivo: prueba aleatoria
        intentos += 1
        if intento == secreto:
            return intentos
        pista = 'mayor' if intento < secreto else 'menor'

if __name__ == "__main__":
    print("Intentos hasta acertar (simulado):", juego_adivina(20))
