class Carrito:
    def __init__(self):
        self.items = []  # {'producto','precio','cantidad'}

    def agregar(self, producto, precio, cantidad=1):
        self.items.append({'producto':producto,'precio':precio,'cantidad':cantidad})

    def eliminar(self, producto):
        self.items = [i for i in self.items if i['producto'] != producto]

    def total(self):
        return sum(i['precio']*i['cantidad'] for i in self.items)

if __name__ == "__main__":
    c = Carrito()
    c.agregar('Manzana', 0.5, 4)
    c.agregar('Leche', 2.0, 1)
    print("Total:", c.total())
