class GestorTareas:
    def __init__(self):
        self.tareas = []  # {'titulo','estado'}

    def agregar(self,titulo):
        self.tareas.append({'titulo':titulo,'estado':'pendiente'})

    def completar(self,titulo):
        for t in self.tareas:
            if t['titulo']==titulo:
                t['estado']='completada'
                return True
        return False

    def listar(self):
        return self.tareas

if __name__ == "__main__":
    g = GestorTareas()
    g.agregar('Comprar leche')
    g.agregar('Estudiar Python')
    g.completar('Comprar leche')
    print(g.listar())
