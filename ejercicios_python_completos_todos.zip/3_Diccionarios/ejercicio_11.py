from collections import Counter
def contar_letras(cadena):
    cadena = cadena.lower()
    return dict(Counter(ch for ch in cadena if ch.isalpha()))

if __name__ == "__main__":
    s = "Hola Mundo"
    print(contar_letras(s))
