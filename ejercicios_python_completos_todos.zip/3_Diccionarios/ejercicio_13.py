class Agenda:
    def __init__(self):
        self.contactos = {}  # nombre -> telefono

    def agregar(self, nombre, telefono):
        self.contactos[nombre] = telefono

    def eliminar(self, nombre):
        return self.contactos.pop(nombre, None)

    def buscar(self, nombre):
        return self.contactos.get(nombre)

if __name__ == "__main__":
    a = Agenda()
    a.agregar('Ana', '300111222')
    a.agregar('Luis', '300333444')
    print("Buscar Ana:", a.buscar('Ana'))
    print("Eliminar Luis:", a.eliminar('Luis'))
    print("Contactos:", a.contactos)
