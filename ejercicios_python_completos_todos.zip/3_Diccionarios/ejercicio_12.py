def invertir_diccionario(d):
    return {v:k for k,v in d.items()}

if __name__ == "__main__":
    d = {'a':1,'b':2,'c':3}
    print(invertir_diccionario(d))
