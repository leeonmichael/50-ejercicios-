def fusionar_diccionarios(d1, d2):
    resultado = d1.copy()
    resultado.update(d2)
    return resultado

if __name__ == "__main__":
    print(fusionar_diccionarios({'a':1}, {'b':2}))
