def filtrar_mayores_que(d, umbral=10):
    return {k:v for k,v in d.items() if v > umbral}

if __name__ == "__main__":
    print(filtrar_mayores_que({'a':5,'b':15,'c':11}, 10))
