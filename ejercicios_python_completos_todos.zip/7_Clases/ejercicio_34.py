class CuentaBancaria:
    def __init__(self, titular, saldo=0.0):
        self.titular = titular
        self.saldo = saldo

    def depositar(self, cantidad):
        if cantidad <= 0:
            raise ValueError("Cantidad positiva requerida")
        self.saldo += cantidad

    def retirar(self, cantidad):
        if cantidad <= 0:
            raise ValueError("Cantidad positiva requerida")
        if cantidad > self.saldo:
            raise ValueError("Fondos insuficientes")
        self.saldo -= cantidad

    def __str__(self):
        return f"Cuenta({self.titular}): {self.saldo}"

if __name__ == "__main__":
    c = CuentaBancaria('Juan', 100.0)
    c.depositar(50)
    try:
        c.retirar(200)
    except Exception as e:
        print("Error:", e)
    print(c)
