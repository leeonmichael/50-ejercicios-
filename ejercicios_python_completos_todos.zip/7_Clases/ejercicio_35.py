class Estudiante:
    def __init__(self, nombre):
        self.nombre = nombre
        self.notas = []

    def agregar_nota(self, n):
        self.notas.append(n)

    def promedio(self):
        if not self.notas:
            return 0
        return sum(self.notas)/len(self.notas)

if __name__ == "__main__":
    e = Estudiante('Luis')
    e.agregar_nota(5)
    e.agregar_nota(4)
    print("Promedio:", e.promedio())
