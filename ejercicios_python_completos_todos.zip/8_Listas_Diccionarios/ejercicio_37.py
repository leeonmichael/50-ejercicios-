def producto_mas_caro(productos):
    if not productos: return None
    return max(productos, key=lambda p: p.get('precio',0))

if __name__ == "__main__":
    productos = [{'nombre':'A','precio':10},{'nombre':'B','precio':25}]
    print(producto_mas_caro(productos))
