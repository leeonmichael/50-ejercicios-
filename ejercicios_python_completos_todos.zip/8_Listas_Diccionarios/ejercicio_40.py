def buscar_por_id(lista, id_):
    for d in lista:
        if d.get('id') == id_:
            return d
    return None

if __name__ == "__main__":
    lista = [{'id':101,'nombre':'Ana'},{'id':102,'nombre':'Luis'}]
    print(buscar_por_id(lista, 102))
