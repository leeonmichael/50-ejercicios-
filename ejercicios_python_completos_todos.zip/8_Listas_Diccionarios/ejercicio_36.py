def filtrar_aprobados(alumnos, umbral=3.0):
    return [a for a in alumnos if a.get('nota',0) >= umbral]

if __name__ == "__main__":
    alumnos = [{'nombre':'Ana','nota':4.0},{'nombre':'Luis','nota':2.5}]
    print(filtrar_aprobados(alumnos))
