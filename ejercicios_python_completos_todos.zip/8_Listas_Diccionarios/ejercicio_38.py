class Inventario:
    def __init__(self):
        self.items = []  # lista de diccionarios con 'id','nombre','cantidad'

    def agregar(self, item):
        self.items.append(item)

    def eliminar_por_id(self, id_):
        self.items = [i for i in self.items if i.get('id') != id_]

    def buscar(self, id_):
        for i in self.items:
            if i.get('id') == id_:
                return i
        return None

if __name__ == "__main__":
    inv = Inventario()
    inv.agregar({'id':1,'nombre':'Lapiz','cantidad':10})
    inv.agregar({'id':2,'nombre':'Cuaderno','cantidad':5})
    print(inv.buscar(2))
    inv.eliminar_por_id(1)
    print(inv.items)
