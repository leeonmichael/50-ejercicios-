def suma_precios(productos):
    return sum(p.get('precio',0) for p in productos)

if __name__ == "__main__":
    productos = [{'nombre':'A','precio':10},{'nombre':'B','precio':25},{'nombre':'C','precio':5}]
    print(suma_precios(productos))
