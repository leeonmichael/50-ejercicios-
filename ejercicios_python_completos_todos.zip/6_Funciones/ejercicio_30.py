class Calculadora:
    def sumar(self,a,b): return a+b
    def restar(self,a,b): return a-b
    def multiplicar(self,a,b): return a*b
    def dividir(self,a,b):
        if b == 0:
            raise ZeroDivisionError("Division por cero")
        return a/b

if __name__ == "__main__":
    calc = Calculadora()
    print(calc.sumar(3,4), calc.restar(10,5), calc.multiplicar(2,6), calc.dividir(8,2))
