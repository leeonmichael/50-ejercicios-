def mayor_de_tres(a,b,c):
    return max(a,b,c)

if __name__ == "__main__":
    print(mayor_de_tres(3,7,5))
