def promedio_lista(lista):
    if not lista:
        return 0
    return sum(lista)/len(lista)

if __name__ == "__main__":
    print(promedio_lista([2,4,6,8]))
